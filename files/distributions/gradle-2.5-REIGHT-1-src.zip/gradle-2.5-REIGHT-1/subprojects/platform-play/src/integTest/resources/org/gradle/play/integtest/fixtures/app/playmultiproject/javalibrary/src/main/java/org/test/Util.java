package org.test;

public class Util {
    public static String fullStop(String input) {
        return input + ".";
    }
}
